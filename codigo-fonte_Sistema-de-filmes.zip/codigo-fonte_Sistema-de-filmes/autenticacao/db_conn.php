<?php

$sname= "localhost";
$unmae= "root";
$password = "220604!rl";

$db_name = "sistemafilmes";

$conn = mysqli_connect($sname, $unmae, $password, $db_name);

if (!$conn) {
	echo "Connection failed!";
}