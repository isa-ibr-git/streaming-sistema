<?php

//define a hora local
date_default_timezone_set('America/Sao_Paulo');

//verifica se a sessão está ativa
if(session_status() !== PHP_SESSION_ACTIVE){
    session_start();
}

//limpa a sessão
limparSessao();


$operacao = null;
$id_filme = null;
$nome = null;
$genero = null;
$duracao = null;
$data_lancamento = null;
$faixa_etaria = null;
$produtora = null;
$imdb = null;
$sinopse = null;
$diretor = null;


//------------------------------------------------------------
//RECUPERA OS CAMPOS
//------------------------------------------------------------

function obterCampos(){
    try{
        global $operacao;
        global $id_filme;
        global $nome;
        global $genero;
        global $duracao;
        global $data_lancamento;
        global $faixa_etaria;
        global $produtora;
        global $imdb;
        global $sinopse;
        global $diretor;

        //RECUPERA OS DADOS DO BOTÃO
        if(isset($_REQUEST["btnOperacao"])){
            $operacao = $_REQUEST["btnOperacao"];
            $operacao = strtoupper($operacao);
        }
        else{
            $operacao = "VAZIO";
        }

        //ID FILME
        if(isset($_REQUEST["ID"])){
            if(!empty($_REQUEST["ID"])){
                $id_filme = $_REQUEST["ID"];
            }            
        }

        //NOME
        if(isset($_REQUEST["txtNome"])){
            if(!empty($_REQUEST["txtNome"])){
                $nome = $_REQUEST["txtNome"];
                $_SESSION['tiulo'] = $nome;
            }            
        }

        //GENERO
        if(isset($_REQUEST["txtGenero"])){
            if(!empty($_REQUEST["txtGenero"])){
                $genero = $_REQUEST["txtGenero"];
                $_SESSION['genero'] = $genero;
            }            
        }

        //DURAÇÃO
        if(isset($_REQUEST["txtDuracao"])){
            if(!empty($_REQUEST["txtDuracao"])){
                $duracao = $_REQUEST["txtDuracao"];
                $_SESSION['duracao'] = $duracao;
            }            
        }

        //DATA DE LANÇAMENTO
        if(isset($_REQUEST["txtLancamento"])){
            if(!empty($_REQUEST["txtLancamento"])){
                $data_lancamento = $_REQUEST["txtLancamento"];
                $_SESSION['ano'] = $data_lancamento;
            }            
        }

        //FAIXA ETÁRIA
        if(isset($_REQUEST["txtFaixa"])){
            if(!empty($_REQUEST["txtFaixa"])){
                $faixa_etaria = $_REQUEST["txtFaixa"];
                $_SESSION['classificacao_indicativa'] = $faixa_etaria;
            }            
        }

        //PRODUTORA
        if(isset($_REQUEST["txtProdutora"])){
            if(!empty($_REQUEST["txtProdutora"])){
                $produtora = $_REQUEST["txtProdutora"];
                $_SESSION['produtora'] = $produtora;
            }            
        }

        //IMDB
        if(isset($_REQUEST["txtImdb"])){
            if(!empty($_REQUEST["txtImdb"])){
                $imdb = $_REQUEST["txtImdb"];
                $_SESSION['nota'] = $imdb;
            }            
        }

        //SINOPSE
        if(isset($_REQUEST["txtSinopse"])){
            if(!empty($_REQUEST["txtSinopse"])){
                $sinopse = $_REQUEST["txtSinopse"];
                $_SESSION['sinopse'] = $sinopse;
            }            
        }

        //RECOMENDAÇÃO
        if(isset($_REQUEST["txtDiretor"])){
            if(!empty($_REQUEST["txtDiretor"])){
                $diretor = $_REQUEST["txtDiretor"];
                $_SESSION['diretor'] = $diretor;
            }            
        }

        






    }catch(Error $ex){

        echo "<h2 style='color:red;'>Erro: " . $ex->getMessage() . "</h2>";
        echo "<p><a href='../paginas/cadastroFilme.php'>Clique aqui para voltar</a></p>";
        die();

    }
}

//----------------------------------------------
//validar campos
//-----------------------------------------------

function validarCampos(){
    try{
        global $nome;
        global $genero;
        global $duracao;
        global $data_lancamento;
        global $faixa_etaria;


        $validar = 1;
        if(empty($nome)){
            $_SESSION['nomeVazio'] = "Por Favor, informe o nome!";
            $validar = 0;
        }


        if(empty($genero)){
            $_SESSION['generoVazio'] = "Por Favor, informe o gênero!";
            $validar = 0;
        }


        if(empty($duracao)){
            $_SESSION['duracaoVazio'] = "Por Favor, informe a duração!";
            $validar = 0;
        }


        if(empty($data_lancamento)){
            $_SESSION['dataVazio'] = "Por Favor, informe o lançamento!";
            $validar = 0;
        }


        if(empty($faixa_etaria)){
            $_SESSION['faixaVazio'] = "Por Favor, informe a faixa etária!";
            $validar = 0;
        }
        return $validar;

    }
    catch(Error $ex){

        echo "<h2 style='color:red;'>Erro: " . $ex->getMessage() . "</h2>";
        echo "<p><a href='../paginas/cadastroFilme.php'>Clique aqui para voltar</a></p>";
        die();

    }
}

//--------------------------------------
//limpa sessão
//------------------------------------

function limparSessao(){
    try{
        unset($_SESSION['titulo']);
        unset($_SESSION['genero']);
        unset($_SESSION['duracao']);
        unset($_SESSION['ano']);
        unset($_SESSION['classificacao_indicativa']);
        unset($_SESSION['produtora']);
        unset($_SESSION['nota']);
        unset($_SESSION['sinopse']);
        unset($_SESSION['diretor']);

        unset($_SESSION['nomeVazio']);
        unset($_SESSION['generoVazio']);
        unset($_SESSION['duracaoVazio']);
        unset($_SESSION['dataVazio']);
        unset($_SESSION['faixaVazio']);

    }
    catch(Error $ex){

        echo "<h2 style='color:red;'>Erro: " . $ex->getMessage() . "</h2>";
        echo "<p><a href='../paginas/cadastroFilme.php'>Clique aqui para voltar</a></p>";
        die();

    }
}

//-----------------------------------------------
//abre conexao
//-------------------------------------------

function abrirConexao(){
    $servidor = "localhost";
    $banco = "sistemaFilmes";
    $usuario = "root";
    $senha = "220604!rl";
    $con = null;


    try{
        $con = new PDO("mysql:host=$servidor;dbname=$banco;charset=utf8", $usuario, $senha);
        //echo "Conexão efetuada com sucesso!<br><br>";

        return $con;




    }
    catch(Error $ex){

        echo "<h2 style='color:red;'>Erro: " . $ex->getMessage() . "</h2>";
        echo "<p><a href='../paginas/cadastroFilme.php'>Clique aqui para voltar</a></p>";
        die();

    }
}

//---------------------------------------------------------
//inserir
//--------------------------------------------------------------------

function inserir(){
    try{

        global $nome;
        global $genero;
        global $duracao;
        global $data_lancamento;
        global $faixa_etaria;
        global $produtora;
        global $imdb;
        global $sinopse;
        global $diretor;


        //validar campos dentro das regras
        if(!validarCampos()){
            return;
        }

        $con = abrirConexao();

        //prepara comando
        $cmdSQL = $con->prepare("INSERT INTO filme(titulo,genero,diretor,classificacao_indicativa,sinopse,ano, produtora,nota,duracao)
                                 VALUES (:titulo,:genero,:diretor,:classificacao_indicativa,:sinopse,:ano,:produtora,:nota,:duracao)");

        //vinculo de parametros com variáveis
        $cmdSQL->bindParam(":titulo", $nome);
        $cmdSQL->bindParam(":genero", $genero);
        $cmdSQL->bindParam(":duracao", $duracao);
        $cmdSQL->bindParam(":ano", $data_lancamento);
        $cmdSQL->bindParam(":classificacao_indicativa", $faixa_etaria);
        $cmdSQL->bindParam(":produtora", $produtora);
        $cmdSQL->bindParam(":nota", $imdb);
        $cmdSQL->bindParam(":diretor", $diretor);
        $cmdSQL->bindParam(":sinopse", $sinopse);
        
        

        //executa comando
        if($cmdSQL->execute()){
            limparSessao();
            //echo "Dados inseridos com sucesso! <br><br>";
            //echo "Linhas afetadas: " .$cmdSQL->rowCount() . "<br>";
            header("Location:../paginas/filmes.php");
        }else{
            echo "Falha na inserção! <br>";
            var_dump($cmdSQL->errorInfo());
            die();
        }
        $con = null;



        
    }
    catch(Error $ex){

        echo "<h2 style='color:red;'>Erro: " . $ex->getMessage() . "</h2>";
        echo "<p><a href='../paginas/cadastroFilme.php'>Clique aqui para voltar</a></p>";
        die();

    }
}

//----------------------------------
//selecionar todos os dadois
//-------------------------------------------

function selecionarTudo(){
    try{

        $con = abrirConexao();


        //prepara comando
        $cmdSQL = $con->prepare("SELECT * FROM filme ");


        if($cmdSQL->execute()){
            $filmes = $cmdSQL->fetchAll();

            $con = null;

            if(count($filmes)){
                return $filmes;

            }
            else{
                return [];
            }


        }else{
            echo "Falha na inserção! <br>";
            var_dump($cmdSQL->errorInfo());
            die();
        }

    }
    catch(Error $ex){

        echo "<h2 style='color:red;'>Erro: " . $ex->getMessage() . "</h2>";
        echo "<p><a href='../paginas/filmes.php'>Clique aqui para voltar</a></p>";
        die();

    }

}

//---------------------------------------------------------
//              SELECIONAR POR ID
//---------------------------------------------------------
function selecionarPorID(){
    try{
        global $id_filme;

        // Abre a conexão
        $con = abrirConexao();

        // Prepara o comando
        $cmdSQL = $con->prepare("SELECT * FROM filme WHERE ID = :idFilme");
       
        // Efetua o vínculo do parâmetro com a variável
        $cmdSQL->bindParam(":idFilme", $id_filme );
        
        // Executa o comando
        if($cmdSQL->execute()){

            // Obtem um array com todos os resultados
            $filmes = $cmdSQL->fetchAll();

            // Fecha conexão
            $con = null;

            if(count($filmes)){
                //print_r($filmes);            
                return  $filmes;
            }
            else{
                return [];
            }
        }
        else{
            echo "Falha na inserção!<br>";
            var_dump($cmdSQL->errorInfo());
            die();
        }      

    }
    catch(Error $ex){
        echo "<h2 style='color: red;'>Erro: " .  $ex->getMessage() . "</h2>";
        echo "<p><a href='../paginas/filmes.php'>Clique aqui para voltar</a></p>";
        die();
    }
}

//------------------------------------
//ALTERAR
//----------------------------------

function atualizar(){
    try{

        global $id_filme;
        global $nome;
        global $genero;
        global $duracao;
        global $data_lancamento;
        global $faixa_etaria;
        global $produtora;
        global $imdb;
        global $sinopse;
        global $diretor;

        //validar campos dentro das regras
        if(!validarCampos()){
            return;
        }

        $con = abrirConexao();

        //prepara comando
        $cmdSQL = $con->prepare("UPDATE filme
                                SET titulo = :titulo,
                                genero = :genero,
                                duracao = :duracao,
                                ano = :ano,
                                classificacao_indicativa = :classificacao_indicativa,
                                produtora = :produtora,
                                nota = :nota,
                                sinopse = :sinopse,
                                diretor = :diretor                                
                                WHERE ID = :idFilme");

        //vinculo de parametros com variáveis
        $cmdSQL->bindParam(":idFilme", $id_filme );
        $cmdSQL->bindParam(":titulo", $nome);
        $cmdSQL->bindParam(":genero", $genero);
        $cmdSQL->bindParam(":duracao", $duracao);
        $cmdSQL->bindParam(":ano", $data_lancamento);
        $cmdSQL->bindParam(":classificacao_indicativa", $faixa_etaria);
        $cmdSQL->bindParam(":produtora", $produtora);
        $cmdSQL->bindParam(":nota", $imdb);
        $cmdSQL->bindParam(":diretor", $diretor);
        $cmdSQL->bindParam(":sinopse", $sinopse);
        

        //executa comando
        if($cmdSQL->execute()){
            limparSessao();
            //redirecionando pra pagina principal
            header("Location:../index.php");
            //echo "Dados inseridos com sucesso! <br><br>";
            //echo "Linhas afetadas: " .$cmdSQL->rowCount() . "<br>";
        }else{
            echo "Falha na atualização! <br>";
            var_dump($cmdSQL->errorInfo());
            die();
        }
        $con = null;

    }
    catch(Error $ex){
        echo "<h2 style='color: red;'>Erro: " .  $ex->getMessage() . "</h2>";
        echo "<p><a href='../paginas/filmes.php'>Clique aqui para voltar</a></p>";
        die();
    }

}

//------------------------------------
//EXCLUIR
//----------------------------------

function excluir(){
    try{
        global $id_filme;

        //validar campos dentro das regras
        if(!validarCampos()){
            return;
        }

        $con = abrirConexao();

        //prepara comando
        $cmdSQL = $con->prepare("DELETE FROM filme 
                                WHERE ID = :idFilme");

        //vinculo de parametros com variáveis
        $cmdSQL->bindParam(":idFilme", $id_filme );
        

        //executa comando
        if($cmdSQL->execute()){
            limparSessao();
            //redirecionando pra pagina principal
            header("Location:../index.php");
            //echo "Dados inseridos com sucesso! <br><br>";
            //echo "Linhas afetadas: " .$cmdSQL->rowCount() . "<br>";
        }else{
            echo "Falha na exclusão! <br>";
            var_dump($cmdSQL->errorInfo());
            die();
        }
        $con = null;

    }
    catch(Error $ex){
        echo "<h2 style='color: red;'>Erro: " .  $ex->getMessage() . "</h2>";
        echo "<p><a href='../paginas/cadastroFilme.php'>Clique aqui para voltar</a></p>";
        die();
    }

}









?>