<?php

//define a hora local
date_default_timezone_set('America/Sao_Paulo');

//verifica se a sessão está ativa
if(session_status() !== PHP_SESSION_ACTIVE){
    session_start();
}

//limpa a sessão
limparSessao();


$operacao = null;
$id_filme = null;
$nome_usuario = null;
$comentario = null;



//------------------------------------------------------------
//RECUPERA OS CAMPOS
//------------------------------------------------------------

function obterCampos(){
    try{
        global $operacao;
        global $id_filme;
        global $nome_usuario;
        global $comentario;

        //RECUPERA OS DADOS DO BOTÃO
        if(isset($_REQUEST["btnOperacao"])){
            $operacao = $_REQUEST["btnOperacao"];
            $operacao = strtoupper($operacao);
        }
        else{
            $operacao = "VAZIO";
        }

        //ID FILME
        if(isset($_REQUEST["ID"])){
            if(!empty($_REQUEST["ID"])){
                $id_filme = $_REQUEST["ID"];
                $_SESSION['ID_filme'] = $id_filme;
            }            
        }

        //NOME
        if(isset($_REQUEST["txtUsuario"])){
            if(!empty($_REQUEST["txtUsuario"])){
                $nome_usuario = $_REQUEST["txtUsuario"];
                $_SESSION['nome_usuario'] = $nome_usuario;
            }            
        }
                     

        //COMENTARIO
        if(isset($_REQUEST["txtcomentario"])){
            if(!empty($_REQUEST["txtcomentario"])){
                $comentario = $_REQUEST["txtcomentario"];
                $_SESSION['comentario'] = $comentario;
            }            
        }

             






    }catch(Error $ex){

        echo "<h2 style='color:red;'>Erro: " . $ex->getMessage() . "</h2>";
        echo "<p><a href='../paginas/cadastroFilme.php'>Clique aqui para voltar</a></p>";
        die();

    }
}

//----------------------------------------------
//validar campos
//-----------------------------------------------

function validarCampos(){
    try{
        global $comentario;


        $validar = 1;
        if(empty($comentario)){
            $_SESSION['comentarioVazio'] = "Por Favor, informe o comentario!";
            $validar = 0;
        }


      
        return $validar;

    }
    catch(Error $ex){

        echo "<h2 style='color:red;'>Erro: " . $ex->getMessage() . "</h2>";
        echo "<p><a href='../paginas/cadastroFilme.php'>Clique aqui para voltar</a></p>";
        die();

    }
}

//--------------------------------------
//limpa sessão
//------------------------------------

function limparSessao(){
    try{
        unset($_SESSION['comentario']);
        

        unset($_SESSION['comentarioVazio']);

    }
    catch(Error $ex){

        echo "<h2 style='color:red;'>Erro: " . $ex->getMessage() . "</h2>";
        echo "<p><a href='../paginas/cadastroFilme.php'>Clique aqui para voltar</a></p>";
        die();

    }
}

//-----------------------------------------------
//abre conexao
//-------------------------------------------

function abrirConexao(){
    $servidor = "localhost";
    $banco = "sistemaFilmes";
    $usuario = "root";
    $senha = "220604!rl";
    $con = null;


    try{
        $con = new PDO("mysql:host=$servidor;dbname=$banco;charset=utf8", $usuario, $senha);
        //echo "Conexão efetuada com sucesso!<br><br>";

        return $con;




    }
    catch(Error $ex){

        echo "<h2 style='color:red;'>Erro: " . $ex->getMessage() . "</h2>";
        echo "<p><a href='../paginas/cadastroFilme.php'>Clique aqui para voltar</a></p>";
        die();

    }
}

//---------------------------------------------------------
//inserir
//--------------------------------------------------------------------

function inserir(){
    try{

        global $id_filme;
        global $nome_usuario;
        global $comentario;

        //validar campos dentro das regras
        if(!validarCampos()){
            return;
        }

        $con = abrirConexao();

        //prepara comando
        $cmdSQL = $con->prepare("INSERT INTO comentario (id_filme, nome_usuario, comentario)
                                 VALUES (:id_filme,:nome_usuario,:comentario)");

        //vinculo de parametros com variáveis
        $cmdSQL->bindParam(":id_filme", $id_filme);
        $cmdSQL->bindParam(":nome_usuario", $nome_usuario);
        $cmdSQL->bindParam(":comentario", $comentario);
        
        

        //executa comando
        if($cmdSQL->execute()){
            limparSessao();
            //echo "Dados inseridos com sucesso! <br><br>";
            //echo "Linhas afetadas: " .$cmdSQL->rowCount() . "<br>";
            header("Location:../paginas/filmes.php");
        }else{
            echo "Falha na inserção! <br>";
            var_dump($cmdSQL->errorInfo());
            die();
        }
        $con = null;



        
    }
    catch(Error $ex){

        echo "<h2 style='color:red;'>Erro: " . $ex->getMessage() . "</h2>";
        echo "<p><a href='../paginas/cadastroFilme.php'>Clique aqui para voltar</a></p>";
        die();

    }
}



function selecionarPorID(){
    try{
        global $id_filme;

        // Abre a conexão
        $con = abrirConexao();

        // Prepara o comando
        $cmdSQL = $con->prepare("SELECT * FROM filme WHERE ID = :idFilme");
       
        // Efetua o vínculo do parâmetro com a variável
        $cmdSQL->bindParam(":idFilme", $id_filme );
        
        // Executa o comando
        if($cmdSQL->execute()){

            // Obtem um array com todos os resultados
            $filmes = $cmdSQL->fetchAll();

            // Fecha conexão
            $con = null;

            if(count($filmes)){
                //print_r($filmes);            
                return  $filmes;
            }
            else{
                return [];
            }
        }
        else{
            echo "Falha na inserção!<br>";
            var_dump($cmdSQL->errorInfo());
            die();
        }      

    }
    catch(Error $ex){
        echo "<h2 style='color: red;'>Erro: " .  $ex->getMessage() . "</h2>";
        echo "<p><a href='../paginas/filmes.php'>Clique aqui para voltar</a></p>";
        die();
    }
}

//----------------------------------
//selecionar todos os dadois
//-------------------------------------------

function selecionarTudo(){
    try{

        $con = abrirConexao();


        //prepara comando
        $cmdSQL = $con->prepare("SELECT * FROM comentario ");


        if($cmdSQL->execute()){
            $comentarios = $cmdSQL->fetchAll();

            $con = null;

            if(count($comentarios)){
                return $comentarios;

            }
            else{
                return [];
            }


        }else{
            echo "Falha na inserção! <br>";
            var_dump($cmdSQL->errorInfo());
            die();
        }

    }
    catch(Error $ex){

        echo "<h2 style='color:red;'>Erro: " . $ex->getMessage() . "</h2>";
        echo "<p><a href='../paginas/filmes.php'>Clique aqui para voltar</a></p>";
        die();

    }

}


