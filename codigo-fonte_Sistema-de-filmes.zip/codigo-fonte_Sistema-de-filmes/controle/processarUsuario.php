<?php

//define a hora local
date_default_timezone_set('America/Sao_Paulo');

//verifica se a sessão está ativa
if(session_status() !== PHP_SESSION_ACTIVE){
    session_start();
}

//limpa a sessão
limparSessao();


$operacao = null;
$nome_usuario = null;
$nome_completo = null;
$senha = null;
$email = null;
$CEP = null;
$logradouro = null;
$numero = null;
$cidade = null;
$bairro = null;
$estado = null;


//------------------------------------------------------------
//RECUPERA OS CAMPOS
//------------------------------------------------------------

function obterCampos(){
    try{
        global $operacao;
        global $nome_usuario;
        global $nome_completo;
        global $senha;
        global $email;
        global $CEP;
        global $logradouro;
        global $numero;
        global $cidade;
        global $bairro;
        global $estado;

        //RECUPERA OS DADOS DO BOTÃO
        if(isset($_REQUEST["btnOperacao"])){
            $operacao = $_REQUEST["btnOperacao"];
            $operacao = strtoupper($operacao);
        }
        else{
            $operacao = "VAZIO";
        }

        

        //NOME USUARIO
        if(isset($_REQUEST["txtNomeUsuario"])){
            if(!empty($_REQUEST["txtNomeUsuario"])){
                $nome_usuario = $_REQUEST["txtNomeUsuario"];
                $_SESSION['nome_usuario'] = $nome_usuario;
            }            
        }

        //SENHA
        if(isset($_REQUEST["txtSenha"])){
            if(!empty($_REQUEST["txtSenha"])){
                $senha = $_REQUEST["txtSenha"];
                $_SESSION['senha'] = $senha;
            }            
        }

        //NOME COMPLETO
        if(isset($_REQUEST["txtNome"])){
            if(!empty($_REQUEST["txtNome"])){
                $nome_completo = $_REQUEST["txtNome"];
                $_SESSION['nome_completo'] = $nome_completo;
            }            
        }

        //EMAIL
        if(isset($_REQUEST["Email"])){
            if(!empty($_REQUEST["Email"])){
                $email = $_REQUEST["Email"];
                $_SESSION['email'] = $email;
            }            
        }

        //CEP
        if(isset($_REQUEST["cep"])){
            if(!empty($_REQUEST["cep"])){
                $CEP = $_REQUEST["cep"];
                $_SESSION['CEP'] = $CEP;
            }            
        }

        //RUA
        if(isset($_REQUEST["rua"])){
            if(!empty($_REQUEST["rua"])){
                $logradouro = $_REQUEST["rua"];
                $_SESSION['logradouro'] = $logradouro;
            }            
        }

        //NUMERO
        if(isset($_REQUEST["numero"])){
            if(!empty($_REQUEST["numero"])){
                $numero = $_REQUEST["numero"];
                $_SESSION['numero'] = $numero;
            }            
        }

        //BAIRRO
        if(isset($_REQUEST["bairro"])){
            if(!empty($_REQUEST["bairro"])){
                $bairro = $_REQUEST["bairro"];
                $_SESSION['bairro'] = $bairro;
            }            
        }

        //CIDADE
        if(isset($_REQUEST["cidade"])){
            if(!empty($_REQUEST["cidade"])){
                $cidade = $_REQUEST["cidade"];
                $_SESSION['cidade'] = $cidade;
            }            
        }

        //ESTADO
        if(isset($_REQUEST["uf"])){
            if(!empty($_REQUEST["uf"])){
                $estado = $_REQUEST["uf"];
                $_SESSION['estado'] = $estado;
            }            
        }

        






    }catch(Error $ex){

        echo "<h2 style='color:red;'>Erro: " . $ex->getMessage() . "</h2>";
        echo "<p><a href='../index.php'>Clique aqui para voltar</a></p>";
        die();

    }
}

//----------------------------------------------
//validar campos
//-----------------------------------------------

function validarCampos(){
    try{
        global $nome_usuario;
        global $nome_completo;
        global $senha;
        


        $validar = 1;
        if(empty($nome_usuario)){
            $_SESSION['nomeUsuarioVazio'] = "Por Favor, informe o nome de usuário!";
            $validar = 0;
        }


        if(empty($senha)){
            $_SESSION['senhaVazio'] = "Por Favor, informe a senha!";
            $validar = 0;
        }


        if(empty($nome_completo)){
            $_SESSION['nomeVazio'] = "Por Favor, informe o seu nome completo!";
            $validar = 0;
        }


        
        return $validar;

    }
    catch(Error $ex){

        echo "<h2 style='color:red;'>Erro: " . $ex->getMessage() . "</h2>";
        echo "<p><a href='../index.php'>Clique aqui para voltar</a></p>";
        die();

    }
}

//--------------------------------------
//limpa sessão
//------------------------------------

function limparSessao(){
    try{
        unset($_SESSION['nomeUsuario']);
        unset($_SESSION['senha']);
        unset($_SESSION['nome']);
        unset($_SESSION['email']);
        unset($_SESSION['Sessaocep']);
        unset($_SESSION['Sessaorua']);
        unset($_SESSION['Sessaonumero']);
        unset($_SESSION['Sessaobairro']);
        unset($_SESSION['Sessaocidade']);
        unset($_SESSION['Sessaoestado']);

        unset($_SESSION['nomeUsuarioVazio']);
        unset($_SESSION['senhaVazio']);
        unset($_SESSION['nomeVazio']);
        

    }
    catch(Error $ex){

        echo "<h2 style='color:red;'>Erro: " . $ex->getMessage() . "</h2>";
        echo "<p><a href='../index.php'>Clique aqui para voltar</a></p>";
        die();

    }
}

//-----------------------------------------------
//abre conexao
//-------------------------------------------

function abrirConexao(){
    $servidor = "localhost";
    $banco = "sistemaFilmes";
    $usuario = "root";
    $senha = "220604!rl";
    $con = null;


    try{
        $con = new PDO("mysql:host=$servidor;dbname=$banco;charset=utf8", $usuario, $senha);
        //echo "Conexão efetuada com sucesso!<br><br>";

        return $con;




    }
    catch(Error $ex){

        echo "<h2 style='color:red;'>Erro: " . $ex->getMessage() . "</h2>";
        echo "<p><a href='../index.php'>Clique aqui para voltar</a></p>";
        die();

    }
}

//---------------------------------------------------------
//inserir
//--------------------------------------------------------------------

function inserir(){
    try{

        global $nome_usuario;
        global $nome_completo;
        global $senha;
        global $email;
        global $CEP;
        global $logradouro;
        global $numero;
        global $cidade;
        global $bairro;
        global $estado;


        //validar campos dentro das regras
        if(!validarCampos()){
            return;
        }

        $con = abrirConexao();

        //prepara comando
        $cmdSQL = $con->prepare("INSERT INTO usuario(nome_usuario,nome_completo,senha,email,CEP,logradouro, numero,cidade,bairro, estado)
                                 VALUES (:nome_usuario,:nome_completo,
                                 :senha,:email,:CEP,:logradouro,:numero,
                                 :cidade,:bairro, :estado)");

        //vinculo de parametros com variáveis
        $cmdSQL->bindParam(":nome_usuario", $nome_usuario);
        $cmdSQL->bindParam(":nome_completo", $nome_completo);
        $cmdSQL->bindParam(":senha", $senha);
        $cmdSQL->bindParam(":email", $email);
        $cmdSQL->bindParam(":CEP", $CEP);
        $cmdSQL->bindParam(":logradouro", $logradouro);
        $cmdSQL->bindParam(":numero", $numero);
        $cmdSQL->bindParam(":cidade", $cidade);
        $cmdSQL->bindParam(":bairro", $bairro);
        $cmdSQL->bindParam(":estado", $estado);
        
        

        //executa comando
        if($cmdSQL->execute()){
            limparSessao();
            //echo "Dados inseridos com sucesso! <br><br>";
            //echo "Linhas afetadas: " .$cmdSQL->rowCount() . "<br>";
            header("Location:../autenticacao/index.php");
        }else{
            echo "Falha na inserção! <br>";
            var_dump($cmdSQL->errorInfo());
            die();
        }
        $con = null;



        
    }
    catch(Error $ex){

        echo "<h2 style='color:red;'>Erro: " . $ex->getMessage() . "</h2>";
        echo "<p><a href='../index.php'>Clique aqui para voltar</a></p>";
        die();

    }
}

//----------------------------------
//selecionar todos os dadois
//-------------------------------------------

function selecionarTudo(){
    try{

        $con = abrirConexao();


        //prepara comando
        $cmdSQL = $con->prepare("SELECT * FROM usuario ");


        if($cmdSQL->execute()){
            $usuarios = $cmdSQL->fetchAll();

            $con = null;

            if(count($usuarios)){
                return $usuarios;

            }
            else{
                return [];
            }


        }else{
            echo "Falha na inserção! <br>";
            var_dump($cmdSQL->errorInfo());
            die();
        }

    }
    catch(Error $ex){

        echo "<h2 style='color:red;'>Erro: " . $ex->getMessage() . "</h2>";
        echo "<p><a href='../index.php'>Clique aqui para voltar</a></p>";
        die();

    }

}