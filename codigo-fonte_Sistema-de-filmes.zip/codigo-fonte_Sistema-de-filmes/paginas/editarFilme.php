<?php

include("../controle/processar.php");

//recuperar os valores dos campos
obterCampos();


if($operacao == "ALTERAR"){
    atualizar();
    header("Location:filmes.php");

}
elseif ($operacao == "CANCELAR"){
    header("Location:filmes.php");
}

//obtem filmes cadastrados
$filmes = selecionarPorID();

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>NEWSFLIX</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="../css/estiloFilmeEspecifico.css">
	<link rel="icon" href="../img/logo.svg" type="image/svg">

	<script type="text/javascript">
        function mostrarDuracao(novoValor) {
            document.getElementById("duracao").innerHTML = novoValor;
        }
    </script>
</head>
<body>

	<div class="titulo">
		<h2>NEWSFLIX</h2>
	</div>

	<!-- <div class="dados">

		<h2>AQUI VÃO OS DADOS DO FILME ESCOLHIDO</h2>
		
	</div> -->
	<div class="recuperacaoDados">
		<form class="row g-3" method="POST" action="">
			<div class="row" id="cadastroPrinc">
				<div class="col-sm-12">
					<p> 
					ID <input class="form-control" type="number" name="txtIdProduto" readonly class="posCampos"                                                                        
											value="<?php
													echo $filmes[0]['ID'];
											?>" />
					</p>
				</div>
				<div class="col-sm-6">
					<p>
						Nome: <input class="form-control" type="text" name="txtNome"  size="100" maxlength ="100"
								value="<?php
													echo $filmes[0]['titulo'];
												
												
												?>" placeholder="<?php
												if(!empty($_SESSION['nomeVazio'])){
													echo "<span class='msgValCampo'>" . $_SESSION['nomeVazio'] . "</span>";
												}
											
											?>">
					</p>
				</div>
				<div class="col-sm-6">
					<p>
						Gênero: <input class="form-control"  type="text" name="txtGenero" size="100" maxlength ="100"
								value="<?php
													echo $filmes[0]['genero'];
												
												
												?>" placeholder="<?php
												if(!empty($_SESSION['generoVazio'])){
													echo "<span class='msgValCampo'>" . $_SESSION['generoVazio'] . "</span>";
												}
											
											?>">
					</p>
				</div>

			<div>
					<p>
						Duração em minutos: <span id="duracao"><?php
											echo $filmes[0]['duracao'];
										
										
										?></span><?php
										if(!empty($_SESSION['duracaoVazio'])){
											echo "<span class='msgValCampo'>" . $_SESSION['duracaoVazio'] . "</span>";
										}
									
									?><input  value="<?php echo $filmes[0]['duracao'] ?>"  id="customRange3" class="form-range" type="range" name="txtDuracao" min="60" max="240" step="2" onchange="mostrarDuracao(this.value)">
					</p>
				</div>

			<div>
				<?php if ($filmes[0]['classificacao_indicativa'] == 1) {
						echo '<div class="col-sm-6">';
						echo '<div class="form-check">';
						echo '<p>';
						echo    '<label>Faixa Etária:</label><br>';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" checked="checked" value="1"> Livre</label> &ensp;&ensp;;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="10"> +10 </label>&ensp;&ensp;&ensp;;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="12"> +12 </label>&ensp;&ensp;&ensp;;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="14"> +14 </label>&ensp;&ensp;&ensp;;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="16"> +16 </label>&ensp;&ensp;&ensp;;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio"  name="txtFaixa" value="18"> +18 </label>';
						echo'</p>';
						echo'</div>';
					echo'</div>';
						
						
					} elseif($filmes[0]['classificacao_indicativa'] == 10) {
						echo '<div class="col-sm-6">';
						echo '<div class="form-check">';
						echo '<p>';
						echo    '<label>Faixa Etária:</label><br>';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio"  name="txtFaixa" value="1"> Livre</label> &ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio"  name="txtFaixa" checked="checked" value="10"> +10 </label>&ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio"  name="txtFaixa" value="12"> +12 </label>&ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio"  name="txtFaixa" value="14"> +14 </label>&ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio"  name="txtFaixa" value="16"> +16 </label>&ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio"  name="txtFaixa" value="18"> +18 </label>';
						echo'</p>';
						echo'</div>';
					echo'</div>';

					}elseif($filmes[0]['classificacao_indicativa'] == 12) {
						echo '<div class="col-sm-6">';
						echo '<div class="form-check">';
						echo '<p>';
						echo    '<label>Faixa Etária:</label><br>';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="1"> Livre</label> &ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="10"> +10 </label>&ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" checked="checked" value="12"> +12 </label>&ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="14"> +14 </label>&ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="16"> +16 </label>&ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="18"> +18 </label>';
						echo'</p>';
						echo'</div>';
					echo'</div>';
					}elseif($filmes[0]['classificacao_indicativa'] == 14) {
						echo '<div class="col-sm-6">';
						echo '<div class="form-check">';
						echo '<p>';
						echo    '<label>Faixa Etária:</label><br>';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="1"> Livre</label> &ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="10"> +10 </label>&ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="12"> +12 </label>&ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" checked="checked" value="14"> +14 </label>&ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="16"> +16 </label>&ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="18"> +18 </label>';
						echo'</p>';
						echo'</div>';
					echo'</div>';
					}elseif($filmes[0]['classificacao_indicativa'] == 16) {
						echo '<div class="col-sm-6">';
						echo '<div class="form-check">';
						echo '<p>';
						echo    '<label>Faixa Etária:</label><br>';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="1"> Livre</label> &ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="10"> +10 </label>&ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="12"> +12 </label>&ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="14"> +14 </label>&ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" checked="checked"  value="16"> +16 </label>&ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="18" > +18 </label>';
						echo'</p>';
						echo'</div>';
					echo'</div>';

					}elseif($filmes[0]['classificacao_indicativa'] == 18) {
						echo '<div class="col-sm-6">';
						echo '<div class="form-check">';
						echo '<p>';
						echo    '<label>Faixa Etária:</label><br>';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="1"> Livre</label> &ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="10"> +10 </label>&ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="12"> +12 </label>&ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="14"> +14 </label>&ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="16"> +16 </label>&ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" checked="checked" value="18"> +18 </label>';
						echo'</p>';
						echo'</div>';
					echo'</div>';

					}else{
						echo '<div class="col-sm-6">';
						echo '<div class="form-check">';
						echo '<p>';
						echo    '<label>Faixa Etária:</label><br>';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="1"> Livre</label> &ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="10"> +10 </label>&ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="12"> +12 </label>&ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="14"> +14 </label>&ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="16"> +16 </label>&ensp;&ensp;&ensp;&ensp;';
						echo    '<label class="form-check-label"><input class="form-check-input"type="radio" name="txtFaixa" value="18"> +18 </label>';
						echo'</p>';
						echo'</div>';
					echo'</div>';
					}
				?>
			</div>
			<?php
					if(!empty($_SESSION['faixaVazio'])){
						echo "<span class='msgValCampo'>" . $_SESSION['faixaVazio'] . "</span>";
					}
				
				?>

			<div class="col-sm-6">
					<div class="input-group date" data-provide="datepicker">
						<p>
							Data de Lançamento: <?php
							if(!empty($_SESSION['dataVazio'])){
								echo "<span class='msgValCampo'>" . $_SESSION['dataVazio'] . "</span>";
							}
						
						?> <input class="form-control"  type="date" name="txtLancamento" 
											value="<?php echo $filmes[0]['ano']; ?>">
						</p>
					</div>
				</div>
			<div class="col-sm-6">
					<p>
						Produtora: <input class="form-control"  type="text" name="txtProdutora" size="100" maxlength ="100"
									value="<?php echo $filmes[0]['produtora']; ?>">
					</p>
				</div>
				<div class="col-sm-6">
					<p>
						IMDB: <input class="form-control" type="number"  name="txtImdb" min="0" max="10" step=".1"
								value="<?php echo $filmes[0]['nota']; ?>">
					</p>
				</div>
				<div class="col-sm-6">
					<p>
						Sinopse: <input class="form-control" type="text" name="txtSinopse"  size="100" maxlength ="2000"
								value="<?php
													echo $filmes[0]['sinopse'];
												
												
												?>" 
											
											>
					</p>
				</div>
				<div class="col-sm-6">
					<p>
						Diretor: <input class="form-control" type="text" name="txtDiretor"  size="100" maxlength ="100"
										value="<?php
													echo $filmes[0]['diretor'];
												
												
												?>">
					</p>
				</div>

                <div class="col-12" id="botaoExcluir">
                <br>
                <p>
                    <input class="btn btn-primary" type="submit" name="btnOperacao" value="Alterar" /> &nbsp; &nbsp;
                    <input class="btn btn-primary" type="submit" name="btnOperacao" value="Cancelar" /> &nbsp; &nbsp;     
                </p>
            </div>
    </form>