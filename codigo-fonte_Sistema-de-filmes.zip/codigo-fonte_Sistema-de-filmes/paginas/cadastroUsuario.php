<?php

include("../controle/processarUsuario.php");

//recuperar os valores dos campos
obterCampos();

if($operacao == "CADASTRAR"){
    inserir();
    //header("Location:../index.php");

}elseif ($operacao == "CANCELAR"){
    header("Location:../index.php");
}

//obtem filmes cadastrados
$usuarios = selecionarTudo();

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>NEWSFLIX</title>
 	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="../css/estiloLogin.css">
    <link rel="icon" href="../img/logo.svg" type="image/svg">
    <script src="../js/scriptAPIcep.js"></script>
</head>
<body>

    <!-- <div class="title">

            <h1>NEWSFLIX</h1>
            
        </div> -->
	<div class="login-box2">
		<form class="row g-3" method="POST" action="">

		<div class="row" >
            <div class="col-sm-6">
                <p>
                    Nome de usuário: <input class="form-control" type="text" name="txtNomeUsuario" size="91" maxlength ="91" 
                            value="<?php
                                                if(!empty($_SESSION['nomeUsuario'])){
                                                    echo $_SESSION['nomeUsuario'];
                                                }
                                            
                                            
                                            ?>"
                                            placeholder="<?php
                        if(!empty($_SESSION['nomeUsuarioVazio'])){
                            echo $_SESSION['nomeUsuarioVazio'];
                        }
                    
                    ?>">
                </p>
            </div>

             <div class="col-sm-6">
                <p>
                    Senha: <input class="form-control" type="password" name="txtSenha" size="11" maxlength ="11" 
                            value="<?php
                                                if(!empty($_SESSION['senha'])){
                                                    echo $_SESSION['senha'];
                                                }
                                            
                                            
                                            ?>"
                                            placeholder="<?php
                        if(!empty($_SESSION['senhaVazio'])){
                            echo $_SESSION['senhaVazio'];
                        }
                    
                    ?>">
                </p>
            </div>

             <div class="col-sm-6">
                <p>
                    Nome completo: <input class="form-control" type="text" name="txtNome" size="101" maxlength ="101" 
                            value="<?php
                                                if(!empty($_SESSION['nome'])){
                                                    echo $_SESSION['nome'];
                                                }
                                            
                                            
                                            ?>"
                                            placeholder="<?php
                        if(!empty($_SESSION['nomeVazio'])){
                            echo $_SESSION['nomeVazio'];
                        }
                    
                    ?>">
                </p>
            </div>

             <div class="col-sm-6">
                <p>
                    Email: <input class="form-control" type="text" name="Email" size="103" maxlength ="103"
                            value="<?php
                                                if(!empty($_SESSION['email'])){
                                                    echo $_SESSION['email'];
                                                }
                                            
                                            
                                            ?>"
                                           >
                </p>
            </div>


            <div class="col-sm-3">
                <p>
                    Cep:
                    <input class="form-control" name="cep" type="text" id="cep" size="10" maxlength="9"
                        onblur="pesquisacep(this.value);" 
                        value="<?php
                                                if(!empty($_SESSION['Sessaocep'])){
                                                    echo $_SESSION['Sessaocep'];
                                                }
                                            
                                            
                                            ?>"/>
                </p>
            </div>

            <div class="col-sm-6">
                <p>
                    Rua:
                    <input class="form-control" name="rua" type="text" id="rua" size="60" 
                    value="<?php
                                                if(!empty($_SESSION['Sessaorua'])){
                                                    echo $_SESSION['Sessaorua'];
                                                }
                                            
                                            
                                            ?>"/>
                </p>
            </div>

            <div class="col-sm-3">
                <p>
                    Número: <input class="form-control" type="text" name="numero" size="10" maxlength ="10"
                            value="<?php
                                                if(!empty($_SESSION['Sessaonumero'])){
                                                    echo $_SESSION['Sessaonumero'];
                                                }
                                            
                                            
                                            ?>"
                                            >
                </p>
            </div>

            <div class="col-sm-3">
                <p>
                    Bairro:
                    <input class="form-control" name="bairro" type="text" id="bairro" size="40" 
                    value="<?php
                                                if(!empty($_SESSION['Sessaobairro'])){
                                                    echo $_SESSION['Sessaobairro'];
                                                }
                                            
                                            
                                            ?>"/>
                </p>
            </div>

            <div class="col-sm-3">
                <p>
                    Cidade:
                    <input class="form-control" name="cidade" type="text" id="cidade" size="40" 
                    value="<?php
                                                if(!empty($_SESSION['Sessaocidade'])){
                                                    echo $_SESSION['Sessaocidade'];
                                                }
                                            
                                            
                                            ?>"/>
                </p>
            </div>

            <div class="col-sm-3">
                <p>
                    Estado:
                    <input class="form-control" name="uf" type="text" id="uf" size="2" 
                    
                    value="<?php
                                                if(!empty($_SESSION['Sessaoestado'])){
                                                    echo $_SESSION['Sessaoestado'];
                                                }
                                            
                                            
                                            ?>"/>
                </p>
            </div>

            <div class="col-sm-3">
                <p>
                    IBGE:
                    <input class="form-control" name="ibge" type="text" id="ibge" size="8" 
                    value="<?php
                                                if(!empty($_SESSION['Sessaoibge'])){
                                                    echo $_SESSION['Sessaoibge'];
                                                }
                                            
                                            
                                            ?>"/>
                </p>
            </div>

            <div class="col-12">
                <br>
                <p>
                    <input class="btn btn-primary" type="submit" name="btnOperacao" value="Cadastrar" /> &nbsp; &nbsp; 
                    
                    <input class="btn btn-primary" type="submit" name="btnOperacao" value="Cancelar" /> &nbsp; &nbsp;     
                   
                </p>
            </div>


       </div>




	</div>
</body>
</html>