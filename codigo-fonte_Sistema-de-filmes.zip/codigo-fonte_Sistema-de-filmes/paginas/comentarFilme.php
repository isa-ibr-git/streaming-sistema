<?php


session_start();

if (isset($_SESSION['nome_usuario'])) {
	include("../controle/processarComentario.php");


    //recuperar os valores dos campos
    obterCampos();

    if($operacao == "COMENTAR"){
        inserir();
        //header("Location:../index.php");
    
    }elseif ($operacao == "COMENTARIOS"){
        header("Location:../paginas/comentarios.php");
    }
    
    //obtem filmes cadastrados
    $filmes = selecionarPorID();

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>NEWSFLIX</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="../css/estiloFilmes.css">
	<link rel="icon" href="../img/logo.svg" type="image/svg">
</head>
<body>
    <div class="titulo">
		<h2>NEWSFLIX</h2>
	</div>

    <div class="user">

		<h2><?php echo $_SESSION['nome_completo'];?></h2> <a href="../autenticacao/logout.php">LOGOUT</a>
		<a href="cadastroFilme.php">CADASTRAR</a>
		
	</div>

    <div class="todoForm">

        <form class="row g-6" method="POST" action="">
                <div class="row" id="cadastroPrinc">
                <div class="col-sm-6">
                        <p>
                            ID Filme: <input readonly class="form-control" type="number" name="txtID" size="100" maxlength ="100"
                                    value="<?php
													echo $filmes[0]['ID'];
											?>"
                                                    placeholder="<?php
                       echo $filmes[0]['ID'];
                    
                    ?>">
                                                    
                        </p>  
                    </div>
                    <div class="col-sm-6">
                        <p>
                            Usuario: <input readonly class="form-control" type="text" name="txtUsuario" size="100" maxlength ="100"
                                    value="<?php
                                                        if(!empty($_SESSION['nome_usuario'])){
                                                            echo $_SESSION['nome_usuario'];
                                                        }
                                                    
                                                    
                                                    ?>"
                                                    placeholder="<?php
                        if(!empty($_SESSION['nome_usuario'])){
                            echo $_SESSION['nome_usuario'];
                        }
                    
                    ?>">
                                                    
                        </p>  
                    </div>
                    <div class="col-sm-6">
                        <p>
                            Comentário: <input class="form-control" type="text" name="txtcomentario" size="100" maxlength ="100"
                                    value="<?php
                                                        if(!empty($_SESSION['comentario'])){
                                                            echo $_SESSION['comentario'];
                                                        }
                                                    
                                                    
                                                    ?>"
                                                    placeholder="<?php
                        if(!empty($_SESSION['comentarioVazio'])){
                            echo $_SESSION['comentarioVazio'];
                        }
                    
                    ?>">
                                                    
                        </p>  
                    </div>
                    <div class="col-6">
                        <br>
                        <p>
                            <input class="btn btn-primary" type="submit" name="btnOperacao" value="comentar" /> &nbsp; &nbsp; 
                            <input class="btn btn-primary" type="submit" name="btnOperacao" value="comentarios" /> &nbsp; &nbsp; 
                            
                        
                        </p>
                    </div>

                </div>
        </form>
    </div>
</body>
</html>

<?php 
}else{
     header("Location: ../paginas/filmes.php");
     exit();
}
 ?>