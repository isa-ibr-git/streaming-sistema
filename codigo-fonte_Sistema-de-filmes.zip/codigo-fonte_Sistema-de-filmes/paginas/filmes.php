<?php 
session_start();

if (isset($_SESSION['nome_usuario'])) {
	include("../controle/processar.php");

	//recuperar os valores dos campos
	obterCampos();


	//obtem filmes cadastrados
	$filmes = selecionarTudo();

 ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>NEWSFLIX</title>
	<link rel="stylesheet" type="text/css" href="../css/estiloFilmes.css">
	<link rel="icon" href="../img/logo.svg" type="image/svg">
</head>
<body>

	<div class="titulo">
		 <h2>NEWSFLIX</h2>
	</div>

	<div class="user">

		<h2><?php echo $_SESSION['nome_completo'];?></h2> <a href="../autenticacao/logout.php">LOGOUT</a>
		<a href="cadastroFilme.php">CADASTRAR</a>
		
	</div>

	<!-- <div class="filmesCadastrados">
		<h2>AQUI VÃO OS FILMES DO SISTEMA </h2>
		<a href="filmeEspecifico.php"> VER DADOS DE UM FILME ESPECÍFICO </a>
	</div> -->

	<div class="todos">
        <?php
            foreach($filmes as $fi){
                $idFi = $fi['ID'];
                $nome = $fi['titulo'];
                            
                echo "<a id='linkDiv' href='filmeEspecifico.php?ID=$idFi'>";
                echo '<div id="conteudoExi">';
                    echo "<p id='txtMostrar'>$nome </p>";
                    

                echo "</div>";
                echo "</a>";
            }

                


        ?>
    </div>

</body>
</html>

<?php 
}else{
     header("Location: ../index.php");
     exit();
}
 ?>