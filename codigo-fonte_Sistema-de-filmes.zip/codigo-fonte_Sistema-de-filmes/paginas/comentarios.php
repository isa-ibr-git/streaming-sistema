<?php 
session_start();
if (isset($_SESSION['nome_usuario'])) {
    include("../controle/processarComentario.php");


    //recuperar os valores dos campos
    obterCampos();


    //obtem filmes cadastrados
    $comentarios = selecionarTudo();

    

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>NEWSFLIX</title>
	<link rel="stylesheet" type="text/css" href="../css/estiloFilmes.css">
	<link rel="icon" href="../img/logo.svg" type="image/svg">
</head>
<body>

	<div class="titulo">
		 <h2>NEWSFLIX</h2>
	</div>

	<div class="user">

		<h2><?php echo $_SESSION['nome_completo'];?></h2> <a href="../autenticacao/logout.php">LOGOUT</a>
		<a href="filmes.php">VOLTAR</a>
		
	</div>

	<!-- <div class="filmesCadastrados">
		<h2>AQUI VÃO OS FILMES DO SISTEMA </h2>
		<a href="filmeEspecifico.php"> VER DADOS DE UM FILME ESPECÍFICO </a>
	</div> -->

	<div class="todos">
        <?php
            foreach($comentarios as $co){
                $idFi = $co['ID_filme'];
                $nome = $co['nome_usuario'];
                $comentario = $co['comentario'];
                            
                
                echo '<div id="conteudoExi">';
                    echo "<p id='txtMostrar'>$nome, filme: $idFi </p>";
                    echo "<p id='txtMostrar'>$comentario </p>";
                    

                echo "</div>";
            }

                


        ?>
    </div>

</body>
</html>

<?php 
}else{
     header("Location: ../index.php");
     exit();
}
 ?>