<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title>NEWSFLIX</title>
	<link rel="stylesheet" type="text/css" href="css/estiloIndex.css">
	<link rel="icon" href="img/logo.svg" type="image/svg">
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.1/jquery.min.js"></script>
	<script>
        //<! [CDATA[]
        $(window).on('load',function(){
            $('.pre').hide().delay(0).fadeIn(0);
            $('.pre').hide().delay(4500).fadeOut(500);
            $('.app').hide().delay(5000).fadeIn(500);
        });
        //]]>
    </script>

</head>
<body>

	<div class="pre">
		<?php include('paginas/preLoader.html')?>
	</div>

	<div class="app">

		<div class="frase">

			<h1>Filmes, Séries, e Muito Mais</h1>
			<a href="paginas/cadastroUsuario.php"> Cadastre-se </a>
			
		</div>

		<div class="entrar">

			<a href="autenticacao/index.php">Entrar</a>
		</div>


 	</div>
	  
</body>
</html>