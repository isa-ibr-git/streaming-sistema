<?php

	class usuario{

		// ATRIBUTOS 

		private $nome_usuario;
		private $nome_completo;
		private $senha;
		private $email;
		private $CEP;
		private $numero;
		private $logradouro;
		private $cidade;
		private $bairro;
		private $estado;
		private $pais;


		//get 


		function getNome_usuario(){
			return $this -> nome_usuario;
		}


		function getNome_completo(){
			return $this -> nome_completo;
		}

		function getSenha(){
			return $this -> senha;
		}

		function getEmail(){
			return $this -> email;
		}

		function getCEP(){
			return $this -> CEP;
		}

		function getNumero(){
			return $this -> numero;
		}

		function getLogradouro(){
			return $this -> logradouro;
		}

		function getCidade(){
			return $this -> cidade;
		}

		function getBairro(){
			return $this -> bairro;
		}

		function getEstado(){
			return $this -> estado;
		}

		function getPais(){
			return $this -> pais;
		}



		//sets


		function setNome_usuario($nome_usuario){
			if (empty($nome_usuario)) {
				throw new Error("O dado não foi informado");
				
			}
			$this -> nome_usuario = $nome_usuario;
		}


		function setNome_completo($nome_completo){
			if (empty($nome_completo)) {
				throw new Error("O dado não foi informado");
				
			}
			$this -> nome_completo = $nome_completo;
		}

		function setSenha($senha){
			if (empty($senha)) {
				throw new Error("O dado não foi informado");
				
			}
			$this -> senha = $senha;
		}

		function setEmail($email){
			if (empty($email)) {
				throw new Error("O dado não foi informado");
				
			}
			$this -> email = $email;
		}

		function setCEP($CEP){
			if (empty($CEP)) {
				throw new Error("O dado não foi informado");
				
			}
			$this -> CEP = $CEP;
		}

		function setNumero($numero){
			if (empty($numero)) {
				throw new Error("O dado não foi informado");
				
			}
			$this -> numero = $numero;
		}

		function setLogradouro($logradouro){
			if (empty($logradouro)) {
				throw new Error("O dado não foi informado");
				
			}
			$this -> logradouro = $logradouro;
		}

		function setCidade($cidade){
			if (empty($cidade)) {
				throw new Error("O dado não foi informado");
				
			}
			$this -> cidade = $cidade;
		}

		function setBairro($bairro){
			if (empty($bairro)) {
				throw new Error("O dado não foi informado");
				
			}
			$this -> bairro = $bairro;
		}

		function setEstado($estado){
			if (empty($estado)) {
				throw new Error("O dado não foi informado");
				
			}
			$this -> estado = $estado;
		}

		function setPaid($pais){
			if (empty($pais)) {
				throw new Error("O dado não foi informado");
				
			}
			$this -> pais = $pais;
		}

		//construtor 

		function __construct()

		{
			$this -> nome_usuario = $nome_usuario;
			$this -> senha = $senha; 
		}
	}
?>