<?php

	class comentario{

		//atributos 

		private $ID_filme;
		private $nome_usuario;
		private $comentario;

		//get 

		function getID_filme(){
			return $this -> ID_filme;
		} 

		function getNome_usuario(){
			return $this -> nome_usuario;
		}

		function getComentario(){
			return $this -> comentario;
		}

		//sets

		function setID_filme($ID_filme){
			if (empty($ID_filme)) {
				throw new Error("O dado não foi informado");
				
			}
			$this -> ID_filme = $ID_filme;
		}

		function setNome_usuario($nome_usuario){
			if (empty($nome_usuario)) {
				throw new Error("O dado não foi informado");
				
			}
			$this -> nome_usuario = $nome_usuario;
		}

		function setComentario($comentario){
			if (empty($comentario)) {
				throw new Error("O dado não foi informado");
				
			}
			$this -> comentario = $comentario;
		}


		//construtor 

		function __construct()

		{
			$this -> ID_filme = $ID_filme;
			$this -> nome_usuario = $nome_usuario;
			$this -> comentario = $comentario;
			
		}

	}
?>