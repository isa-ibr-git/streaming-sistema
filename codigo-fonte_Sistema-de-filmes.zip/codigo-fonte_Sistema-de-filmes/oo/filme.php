<?php

	class filme{

		//atributos

		private $ID;
		private $titulo;
		private $genero;
		private $diretor;
		private $classificacao;
		private $sinopse;
		private $ano;
		private $produtora;
		private $nota;
		private $duracao;

		//get


		function getID(){
			return $this -> ID;
		}

		function getTitulo(){
			return $this -> titulo;
		}

		function getGenero(){
			return $this -> genero;
		}

		function getDiretor(){
			return $this -> diretor;
		}

		function getClassificacao(){
			return $this -> classificacao;
		}

		function getSinopse(){
			return $this -> sinopse;
		}

		function getAno(){
			return $this -> ano;
		}

		function getProdutora(){
			return $this -> produtora;
		}

		function getNota(){
			return $this -> nota;
		}

		function getDuracao(){
			return $this -> duracao;
		}


		//sets


		function setTitulo($titulo){
			if (empty($titulo)) {
				throw new Error("O dado não foi informado");
				
			}
			$this -> titulo = $titulo;
		}

		function setGenero($genero){
			if (empty($genero)) {
				throw new Error("O dado não foi informado");
				
			}
			$this -> genero = $genero;
		}

		function setDiretor($diretor){
			if (empty($diretor)) {
				throw new Error("O dado não foi informado");
				
			}
			$this -> diretor = $diretor;
		}

		function setClassificacao($classificacao){
			if (empty($classificacao)) {
				throw new Error("O dado não foi informado");
				
			}
			$this -> classificacao = $classificacao;
		}

		function setSinopse($sinopse){
			if (empty($sinopse)) {
				throw new Error("O dado não foi informado");
				
			}
			$this -> sinopse = $sinopse;
		}

		function setAno($ano){
			if (empty($ano)) {
				throw new Error("O dado não foi informado");
				
			}
			$this -> ano = $ano;
		}

		function setProdutora($produtora){
			if (empty($produtora)) {
				throw new Error("O dado não foi informado");
				
			}
			$this -> produtora = $produtora;
		}

		function setNota($nota){
			if (empty($nota)) {
				throw new Error("O dado não foi informado");
				
			}
			$this -> nota = $nota;
		}

		function setDuracao($duracao){
			if (empty($duracao)) {
				throw new Error("O dado não foi informado");
				
			}
			$this -> duracao = $duracao;
		}


		//construtor 


		function __construct()

		{
			$this -> ID = $ID;
			$this -> titulo = $titulo;
			$this -> genero = $genero;
			$this -> diretor = $diretor;
			$this -> classificacao = $classificacao; 
			$this -> sinopse = $sinopse;
			$this -> ano = $ano;
			$this -> produtora = $produtora;
			$this -> nota = $nota;
			$this -> duracao = $duracao;
		}



		

		
	}
?>